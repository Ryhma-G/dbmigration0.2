﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using Cassandra;
using Cassandra.Data.Linq;
using System.Data.Entity.SqlServer;
using System.Numerics;

namespace DbMigration
{
    //measurement table context
   public class MeasurementContext : DbContext
    {
        public MeasurementContext() : base("SavoniaMeasurementsV2Entities") { }
        public DbSet<Measurement> Measurement { get; set; }
    }
    //Data table context
    public class DataContext : DbContext
    {
        public DataContext() : base("SavoniaMeasurementsV2Entities") { }
        public DbSet<Data> Data { get; set; }
    }
    //data and measurement table context
    public class DaMeContext : DbContext
    {
        public DaMeContext() : base("SavoniaMeasurementsV2Entities") { }
        public DbSet<Measurement> Measurement { get; set; }
        public DbSet<Data> Data { get; set; }
    }
    
    public class DbGeography
    {
        public Nullable<double> Latitude { get; }
        public Nullable<double> Longitude { get; }
    }
   
    class Program
    {
        static void Main(string[] args)
        {

            //Cassandra connection
            var cluster = Cluster.Builder()
                                .AddContactPoints("Samidb.ky.local")
                                .WithPort(9042)

                                .Build();

            // Connect to the nodes using a keyspace
            var session = cluster.Connect("samiv4");
         
            var cqlquery = session.Prepare("INSERT INTO samiv4.measurementdata(providerid, sensortag, timebucket, timestamp, measurementobject, measurementtag, location, doublevalue, decimalvalue, longvalue, bigintvalue, listvalue, note, textvalue, binaryvalue ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); ");
           
            var batch = new BatchStatement();
            
            using (var context3 = new DaMeContext())
            {               

                try
                {
                    //fetch data from measurement and data tables
                    var query = (from m in context3.Measurement
                                      join d in context3.Data on m.ID equals d.MeasurementID
                                      where m.ID == d.MeasurementID
                                      select new
                                      {
                                          providerid = m.ProviderID,
                                          sensortag = d.Tag,
                                          //timebucket = SqlFunctions.DatePart("yyyy", m.Timestamp) + "-" + SqlFunctions.DatePart("MM", m.Timestamp),
                                          timebucket = m.Timestamp.Year.ToString() + "-" + m.Timestamp.Month.ToString(),                                                                                             
                                          timestamp = m.Timestamp,
                                          measurementobject = m.Object,
                                          measurementtag = m.Tag,
                                          //location = m.Location.Latitude + "," + m.Location.Longitude, ei toimi
                                          location = m.Location,
                                          doublevalue = d.Value,
                                          decimalvalue = d.Value,
                                          longvalue = d.LongValue,
                                          bigintvalue = m.ID,
                                          listvalue = d.XmlValue,
                                          //mapvalue =  ,
                                          note = m.Note,
                                          textvalue = d.TextValue,
                                          binaryvalue = d.BinaryValue,
                                          
                                      }).Take(1);

                    foreach(var row in query)
                    {
                        Console.WriteLine("providerid: " + row.providerid + " sensortag: " + row.sensortag + " timebucket: " + row.timebucket + " timestamp: " + row.timestamp + " measurementobject: " + 
                            row.measurementobject + " measurementtag: " + row.measurementtag +" location: " + row.location + " doublevalue: " + row.doublevalue + " decimalvalue: " + row.decimalvalue  + " longvalue: " + row.longvalue +
                            " bigintvalue: " + row.bigintvalue + " listvalue: " + row.listvalue + "note: " + row.note + "textvalue: " + row.textvalue + "binaryvalue: " + row.binaryvalue);                       
                        //add values to batch
                        batch.Add(cqlquery.Bind(row.providerid, row.sensortag, row.timebucket, row.timestamp, row.measurementobject, row.measurementtag, row.location, row.doublevalue, row.decimalvalue, row.longvalue, row.bigintvalue, row.listvalue, row.note, row.textvalue, row.binaryvalue));
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine(e.Message);
                }
               
            }
            
            
            session.Execute(batch);

         

            // Get name of a Cluster
            Console.WriteLine("The cluster's name is: " + cluster.Metadata.ClusterName);

            // Execute a query on a connection synchronously
            
            var rs = session.Execute("SELECT * FROM samiv4.measurementdata WHERE providerid = 3 ALLOW FILTERING");

            

            // Iterate through the RowSet (read)
            foreach (var row in rs)
             {
                var value = row.GetValue<int>("providerid");
                var value2 = row.GetValue<string>("sensortag");
                var value3 = row.GetValue<string>("timebucket");
                var value4 = row.GetValue<DateTime>("timestamp");
                var value5 = row.GetValue<string>("measurementobject");
                var value6 = row.GetValue<string>("measurementtag");
                Console.WriteLine(value + "  " + value2 + " " + value3 + " " + value4 + " " + value5 + " " + value6);
                 
             }
             Console.ReadKey();
             
            
            
    }
    }
}
