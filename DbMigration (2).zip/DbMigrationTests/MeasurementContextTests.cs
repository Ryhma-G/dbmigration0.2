﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using DbMigration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbMigration.Tests
{
    [TestClass()]
    public class MeasurementContextTests
    {
        [TestMethod()]
        public void MeasurementContextTest()
        {
            Assert.Fail();
        }
    }
}